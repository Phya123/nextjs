# Placeholder for data loader
def load_historical_data(symbol): return []