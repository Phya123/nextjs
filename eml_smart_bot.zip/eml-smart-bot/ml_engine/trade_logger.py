# Placeholder for logging trades
def log_trade(symbol, qty, side, price): pass