import os
from alpaca_trade_api.rest import REST
API_KEY = os.getenv("ALPACA_API_KEY")
API_SECRET = os.getenv("ALPACA_API_SECRET")
BASE_URL = os.getenv("ALPACA_BASE_URL", "https://paper-api.alpaca.markets")
alpaca = REST(API_KEY, API_SECRET, BASE_URL, api_version='v2')
def place_order(symbol: str, qty: float, side: str):
    order = alpaca.submit_order(symbol=symbol, qty=qty, side=side, type='market', time_in_force='gtc')
    return order
