import { useState } from "react";
export default function Dashboard() {
  const [message, setMessage] = useState("");
  const triggerTrade = async () => {
    const res = await fetch("/api/trade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol: "AAPL", side: "buy" }),
    });
    const data = await res.json();
    setMessage(data.prediction || data.message);
  };
  return (<div style={{ padding: "2rem" }}>
      <h1>EML Smart Trading Dashboard</h1>
      <button onClick={triggerTrade}>Run Trade</button>
      <p>{message}</p>
    </div>);
}
