import { exec } from "child_process";
export default async function handler(req, res) {
  if (req.method === "POST") {
    const { symbol, side } = req.body;
    exec(`python3 ../../ml_engine/predict.py`, (err, stdout, stderr) => {
      if (err) return res.status(500).json({ error: stderr });
      res.status(200).json({ message: "Trade executed", prediction: stdout });
    });
  } else { res.status(405).json({ message: "Method not allowed" }); }
}
